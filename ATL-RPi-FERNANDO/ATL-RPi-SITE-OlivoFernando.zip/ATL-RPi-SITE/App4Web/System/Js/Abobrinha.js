  var _portal_teste = "Abobrinha123";
  function showTeste() {
	  alert ("-> "+ _portal_teste);
  }  
  function showTeste2(a) {
	  alert ("-> "+ _portal_teste+ " A: "+ a);
  }  