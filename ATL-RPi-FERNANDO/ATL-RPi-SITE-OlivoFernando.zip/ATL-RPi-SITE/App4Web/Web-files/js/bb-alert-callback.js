bootbox.alert("Hello world!", function() {
  Example.show("Hello world callback");
});