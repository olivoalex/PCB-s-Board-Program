/**
 * appm000300_AJAX.js
 */
function processarAJAX(aOnde){	
	alert("Processar Ajax appm000300_AJAX.js"+ aOnde);	
}