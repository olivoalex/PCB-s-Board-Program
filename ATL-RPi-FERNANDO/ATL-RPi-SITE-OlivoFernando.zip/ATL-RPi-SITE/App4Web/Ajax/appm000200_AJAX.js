/**
 * appm000200_AJAX.js
 */
function processarAJAX(aOnde){	
	alert("Processar Ajax appm000200_AJAX.js"+ aOnde);	
}